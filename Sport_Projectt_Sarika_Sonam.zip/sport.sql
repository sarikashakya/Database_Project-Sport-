-- Creating database
create database Player_info;
use Player_info;
-- Task 1: Design Tables
-- Teams table:
CREATE TABLE Teams (
    team_id int primary key auto_increment,
    team_name VARCHAR(100),
    coach_name VARCHAR(100),
    city VARCHAR(100)
);

-- inserting values in table
insert into teams(team_name,coach_name, city)value
    ('Red Lions', 'Paul Anderson', 'New York'),
    ('Blue Sharks', 'Linda Brown', 'Los Angeles'),
    ('Green Warriors', 'Carlos Mendoza', 'Chicago'),
    
-- retrieving data from table
select * from temes;


-- create 2nd table
CREATE TABLE Players (
    player_id int primary key auto_increment,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    date_of_birth DATE,
    position VARCHAR(50),
    team_id INT, 
    FOREIGN KEY (team_id) REFERENCES Teams(team_id)
);
INSERT INTO Players (first_name, last_name, date_of_birth, position, team_id)values
    ('John', 'Doe', '1990-05-15', 'Forward', 1),
    ('Jane', 'Smith', '1992-03-20', 'Midfielder', 2),
    ('David', 'Johnson', '1988-08-10', 'Goalkeeper', 1),
    ('Emma', 'Williams', '1994-12-25', 'Defender', 3),
    ('Michael', 'Brown', '1989-01-30', 'Forward', 3);
select * from Players;

-- creating 3rd table
CREATE TABLE Matches (
    match_id int primary key auto_increment,
    home_team_id INT,
    away_team_id INT,  
    match_date DATE,
    location VARCHAR(100),
    FOREIGN KEY (home_team_id) REFERENCES Teams(team_id),
    FOREIGN KEY (away_team_id) REFERENCES Teams(team_id)
);

-- inserting the values in table
INSERT INTO Matches (home_team_id, away_team_id, match_date, location)
VALUES
    (1, 2, '2025-03-15', 'New York Stadium'),
    (2, 3, '2025-03-16', 'Los Angeles Arena'),
    (1, 3, '2025-03-17', 'New York Stadium');
    
-- retrieving the data 
select * from Matches;

-- 4th table
CREATE TABLE Scores (
    score_id int primary key auto_increment,
    match_id INT,  
    home_team_score INT,
    away_team_score INT,
    FOREIGN KEY (match_id) REFERENCES Matches(match_id)
);

-- inserting the values in table
INSERT INTO Scores (match_id, home_team_score, away_team_score)
VALUES
    (1, 3, 2), 
    (2, 1, 2),  
    (3, 2, 2);  
    
-- retrieving the data 
select * from Scores;

-- Creating index for getting specific data
CREATE INDEX idx_player_name
ON Players (first_name, last_name);

-- retreiving data by using indexing 
SELECT * FROM Players WHERE first_name = 'John' AND last_name = 'Doe';

-- Creating triggers for update specific player
DELIMITER $$
CREATE TRIGGER update_player_team
AFTER UPDATE ON Teams
FOR EACH ROW
BEGIN
    IF OLD.team_id != NEW.team_id THEN
        UPDATE Players
        SET team_id = NEW.team_id
        WHERE team_id = OLD.team_id;
    END IF;
END $$
DELIMITER ;

SELECT * FROM Players WHERE team_id = 1;

UPDATE Teams 
SET team_id = 2 
WHERE team_id = 1;  
SELECT * FROM Players WHERE team_id = 2;

